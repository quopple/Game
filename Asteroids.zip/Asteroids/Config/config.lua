scriptPath="GameScrips"
resPath="GameRes"
