--[[
    小行星类
]]

require('Vec2')
require('Definition') 
require('Collider')         

Asteroid            = Collider:new()

Asteroid.position   = ZERO_VEC
Asteroid.velocity   = ZERO_VEC

Asteroid.animator   = nil


 --每个小行星对象有自己的位置，大小，移动方向，动画绘制器
function Asteroid:new( x,y,scale,orientation,animator )     
    local obj       = {}
    setmetatable( obj,self )
    self.__index    = self

    local radian    = math.rad( orientation )      
    obj.animator    = animator
    obj.scale       = scale
    obj.position    = Vec2:new(x,y)
    obj.velocity    = Vec2:new( math.cos(radian)*ASTEROID_SPEED,math.sin(radian)*ASTEROID_SPEED  )     --使用统一定义的初速度大小
  
    return obj
end



function Asteroid:randomChangeVelocity()
    local vel = self.velocity
    local symbel = {1,-1}
    
    --约束xy方向上的速度分量最大值
    if vel.x < ASTEROID_MAX_VAL then
        vel.x = vel.x + math.random( ) * symbel[ math.random(2) ]
        vel.x =( math.abs( vel.x ) <= SHIP_MAX_VAL ) and vel.x or ( vel.x/math.abs(vel.x)*SHIP_MAX_VAL )   
    end
    if vel.y < ASTEROID_MAX_VAL then       
        vel.y = vel.y + math.random(  )* symbel[ math.random(2) ]
        vel.y =( math.abs( vel.y ) <= SHIP_MAX_VAL ) and vel.y or ( vel.y/math.abs(vel.y)*SHIP_MAX_VAL )
    end
end


function Asteroid:updateVelocity(surviveTime)
    local speed  = ASTEROID_SPEED + surviveTime*ASTEROID_ACCELERATION
    local radian = math.rad( math.random( 360 ) )
    local vel    = Vec2:new( math.cos(radian)*speed,math.sin(radian)*speed  )
    
    --约束xy方向上的速度分量最大值
    vel.x = ( math.abs( vel.x ) <= SHIP_MAX_VAL ) and vel.x or ( vel.x/math.abs(vel.x)*SHIP_MAX_VAL )   

    vel.y = ( math.abs( vel.y ) <= SHIP_MAX_VAL ) and vel.y or ( vel.y/math.abs(vel.y)*SHIP_MAX_VAL )

    self.velocity = vel
end


function Asteroid:updatePos( surviveTime )
--    self:randomChangeVelocity()
    local newPos = Vec2.add( self.position,self.velocity)       --根据速度向量更新位置
    local needUpdateVel = false

    --当移动到了屏幕外面,wrap
    if newPos.x > WIDTH then 
        newPos.x        = -self.scale
        needUpdateVel   = true             
    elseif newPos.x + self.scale < 0 then 
        newPos.x        = WIDTH  
        needUpdateVel   = true   
    end
    if newPos.y > HEIGHT then 
        newPos.y        = -self.scale 
        needUpdateVel   = true   
    elseif newPos.y + self.scale < 0 then  
        newPos.y        = HEIGHT 
        needUpdateVel   = true   
    end
    
    if needUpdateVel then self:updateVelocity(surviveTime) end
    self.position = newPos
end


function Asteroid:draw()
    self.animator:draw( {x = self.position.x,y = self.position.y} )
end


--每一帧调用，更新位置信息并绘制
function Asteroid:update(surviveTime)
    self:updatePos(surviveTime)        
    self:draw()
end


--使用简单的圆包围盒进行碰撞检测
function Asteroid:collisionDetect( obj )
--[[    if isBoxOverlap( self.position.x,self.position.y,self.scale,self.scale,
                     obj.position.x,obj.position.y,obj.scale,obj.scale) 
    then return true
    else return false
    end
    ]]
    local r1 = self.scale/2
    local r2 = obj.scale/2
    if isOverlap( self.position.x + r1,self.position.y + r1,r1,
                  obj.position.x + r2,obj.position.y + r2,r2)
    then return true
    else return false
    end
end


--小行星被碰撞事件的处理函数
--这里根据双方的大小，简单进行速度向量相加，模拟物理碰撞
function Asteroid:onCollide( collider )
    local weight1 = self.scale/( self.scale+collider.scale )
    local weight2 = collider.scale/( self.scale+collider.scale )
    self.velocity = Vec2.add( self.velocity:mul(weight1) ,collider.velocity:mul(weight2) )
end