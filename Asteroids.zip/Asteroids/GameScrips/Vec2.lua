--[[
    二维向量类
    定义了一些向量操作
]]
Vec2 = {}

Vec2.x = 0
Vec2.y = 0


function Vec2:new(x,y)
    local obj = {}
    obj.x = x or 0
    obj.y = y or 0

    setmetatable( obj,self )
    self.__index = self

    return obj
end


function Vec2.add( v1,v2 )
    local res = Vec2:new( v1.x + v2.x,v1.y + v2.y)
    return res
end


function Vec2.sub( v1,v2 )
    local res = Vec2:new(v1.x - v2.x,v1.y - v2.y )
    return res
end


--点乘
function Vec2.dot( v1,v2 )
    return v1.x*v2.x + v1.y*v2.y
end


--叉乘
function Vec2.cross( v1,v2 )
    return v1.x*v2.y - v2.x*v1.y
end


--归一化
function Vec2.normalize( v )
    local xxyy = math.sqrt( v.x*v.x + v.y*v.y )
    local res  = Vec2:new( v.x/xxyy,v.y/xxyy )
    return res
end


--标量乘法
function Vec2.mul( v, num )
    local res = Vec2:new( v.x*num,v.y*num )
    return res
end


function Vec2.length(v1,v2)
    local t   = Vec2.sub(v1,v2)
    local res = math.sqrt( t.x*t.x + t.y*t.y )
    return res
end