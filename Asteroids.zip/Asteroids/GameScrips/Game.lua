package.path = package.path ..";GameScrips/?.lua"

require( "Painter" )
require( "Logger" )
require( "Ship" )
require( "Bullet" )
require( "Definition" )
require( "ResourceManager" )
require( "BulletManager" )
require( "AsteroidManager" )
require( "Asteroid" )
require( "CollisionTraverser" )
require( "Animate" )


------------------------------------------helper function---------------------------------------

--[[
作用：加载并返回一个所有飞船图片的集合 以及 大小
注释：飞船图片集合是顺时针顺序的八方向图，这么做是为了与坐标原点在左上角，x,y轴正半轴分别朝向左、下的屏幕坐标系相适应，从而能在程序中以正常的逆时针顺序角度处理
]]
function getShipImgSet( )
    shipImgSet      = {}

    for i = 0,359,45 do     
        local path  = string.gsub( SHIP_IMG,'(%w+)%.png$','%1'..i..'%.png' )
        local imgID = ResourceManager.getImage( path )
        if    imgID ~= -1 then  shipImgSet[i] = imgID  end       
    end

    return shipImgSet,Painter.getImageW(shipImgSet[ table.maxn( shipImgSet ) ])
end


--[[
作用：加载并返回一个所有小行星类型的集合，每个元素是一个{ animator,scale }二元组
注释：animator,该类型小行星的动画对象    scale,该类型小行星的大小
]]
function getAsteroidTypeSet( )
    local asteroidTypeSet     = {}

    for i,v in ipairs( ASTEROID_TYPE ) do
        local asteroidType    = {}
        local imgID           = ResourceManager.getImage( v )  
        asteroidType.animator = Animate:new( imgID,Painter )
        asteroidType.scale    = Painter.getImageW( imgID )
        if imgID ~= -1 then
            asteroidTypeSet[ #asteroidTypeSet + 1 ] = asteroidType
        end
    end

    return asteroidTypeSet
end


--[[
    显示游戏提示文本
]]
function showTextBox()
    Painter.drawText(10,10, "Avoid all asteroids or fire to push them away and survive as much as you can" )
    Painter.drawText(10,30,  "ESC          : Quit")
    Painter.drawText(10,50,  "[Left Arrow] : Turn Left (CCW)")
    Painter.drawText(10,70,  "[Right Arrow]: Turn Right (CW)")
    Painter.drawText(10,90,  "[Up Arrow]   : Accelerate")
    Painter.drawText(10,110, "[Space Bar]  : Fire")
    Painter.drawText(10,130, os.date() )
    Painter.drawText(10,150, "survive      : ".. (  surviveTime )..'S')
end


--[[
    游戏结束或esc退出时的文本提示框
]]
function exitTextBox()
    local imgID = ResourceManager.getImage( TEXTBOX_IMG )
    local w     = Painter.getImageW(imgID)
    local h     = Painter.getImageH(imgID)
    Painter.drawImage( imgID,(WIDTH-w)/2,(HEIGHT-h)/2,0,0 )
    Painter.drawText ( (WIDTH-w )/2+50 ,(HEIGHT)/2 ,"GameOver,press Enter to Quit" )
end
------------------------------------------主要程序逻辑---------------------------------------

function GameInit()
    Painter.setCanvas(WIDTH,HEIGHT)                     --设置窗口            
    Painter.setTextColor( RGB(131,175,155) )

    --创建并初始化游戏组件
    log                 = Logger:new()          
    background          = ResourceManager.getImage( BG_IMG )     


    --子弹管理器
    local bulletImg     = ResourceManager.getImage(BULLET_IMG)
    bulletManager       = BulletManager:new( Animate:new( bulletImg,Painter), Painter.getImageW( bulletImg  ) )      
    
    --小行星管理器
    asteroidManager     = AsteroidManager:new(  getAsteroidTypeSet() )        

    --飞船对象
    local shipImg,scale = getShipImgSet( )
    ship                = Ship:new( Animate:new( shipImg,Painter ),scale )                                 

    numOfAsteroid       = math.random( ASTEROID_MIN_NUM,ASTEROID_MAX_NUM )    --要生成的小行星数量
    for i = 1,numOfAsteroid do 
        local asteroid  = asteroidManager:genAsteroid( ship )
        CollisionTraverser:addColliderGroup( asteroid,bulletManager.bulletPool )     --将每个小行星对象与子弹数组放入碰撞检测器，即对每个小行星检测是否与所有子弹发生碰撞
    end

    --将飞船对象与小行星数组放入碰撞检测器
    CollisionTraverser:addColliderGroup( ship,asteroidManager.asteroidPool )


    Painter.playMusic( ResourceManager.getMusic(BGM) )
    Painter.setGameName(GAMENAME)
    Painter.setCursor(CURSOR)

    surviveTime = 0
    beginTime   = os.time()

    log:print( 'init success' )
end


function GameLoop()   --游戏主循环函数(接口函数)
    Painter.drawImage( background,0,0,0,0 )  --每一帧都绘制背景，覆盖前一帧图像
    showTextBox()

    if  ship.alive then 
        surviveTime = os.time() - beginTime
        ship:update()   
        asteroidManager:update(surviveTime)
        bulletManager:update()
        CollisionTraverser:update()
    else
        exitTextBox()   --如果飞船已经撞到小行星，游戏结束   
    end

    Painter.updateCanvas()
end


--游戏退出前的清理工作
function GameExit()
    asteroidManager:destroy()
    bulletManager:destroy()

    log:print( 'exit' )
    log:destroy()

    Painter.exitGame()
end


function OnVKeyDown(nKey,nRep) --功能键按下响应函数（接口函数）
    if nKey     == 38 then -- 按↑
        ship:accelerate()
    elseif nKey == 37 then --按←
        ship.orientation = ( ship.orientation + 360 - 45 )%360
    elseif nKey == 39 then --按→
        ship.orientation = ( ship.orientation + 45 )%360
    elseif nKey == 32 then --按space
        ship:fire(bulletManager) 
    elseif nKey == 27 then --按esc
        ship.alive = false
    elseif nKey == 13 then --按enter键
        if not ship.alive then GameExit() end
    end
end

