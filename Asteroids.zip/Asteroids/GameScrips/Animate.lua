--[[
    所有可绘制对象的一个组件，封装图像的管理和绘制
]]

Animate = {}

Animate.img     = nil   --管理的图像资源
Animate.painter = nil   --画笔，实际绘图对象


function Animate:new( img,painter )
    local obj    = {}
    setmetatable( obj,self )
    self.__index = self

    obj.img      = img
    obj.painter  = painter

    return obj
end


function Animate:draw( param )
    local imgID = ( param.index and self.img[ param.index ] ) or self.img
    self.painter.drawImage( imgID, param.x or 0, param.y or 0, param.left or 0,param.width or 0 )
end