Logger = {}

function Logger:new( path )
    path         = path or './log.txt'

    local obj    = {}
    obj.out      = io.open(path,'a')

    setmetatable( obj,self )
    self.__index = self
    return obj
end


local function tostring( msg )
    if      type(msg) == 'string' or type(msg) == 'number' then
        return msg

    elseif  type( msg ) == 'boolean' then
        return msg and 'true' or 'false'
    elseif  type( msg ) == 'table' then
        local str = '{'
        for k,v in pairs( msg ) do
            str = str .. '[ '..tostring(k).." : "..tostring(v) ..' ],'
        end
        return str..'}'
    else
        return ''
    end
end


function Logger:print( ... )
    self.out:write( os.date() , " : ",tostring({...}),'\n' )
    self.out:flush()
end


function Logger:destroy()
    self.out:flush()
    self.out:close()
end


