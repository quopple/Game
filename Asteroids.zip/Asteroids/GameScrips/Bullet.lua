--[[
    子弹类
]]
require( 'Painter' )
require( 'Definition' )
require( 'Collider' )
require( 'Vec2' )

Bullet = Collider:new()
Bullet.animator      = nil
Bullet.position = ZERO_VEC
Bullet.velocity = ZERO_VEC
Bullet.scale    = 0      --子弹大小  用于包围盒判断

Bullet.expire   = 0      --消失的时间


function Bullet:new( x,y,orientation,animator,scale )
    local obj       = {}
    setmetatable( obj,self )
    self.__index    = self

    local radian    = math.rad( orientation )
    obj.position    = Vec2:new( x,y )
    obj.velocity    = Vec2:new( math.cos( radian )*BULLET_SPEED,math.sin( radian )*BULLET_SPEED )  
    obj.expire      = os.time() + BULLET_LIFE  --小行星的消亡时间 = 生成时间 + 存活时间
    obj.animator         = animator
    obj.scale       = scale
    return obj
end


--更新子弹位置，当飞出屏幕范围内时，将子弹消亡时间设为0，由子弹管理器移除子弹对象
function Bullet:updatePos( )
    local newPos = Vec2.add( self.position,self.velocity )

    if newPos.x + self.scale < 0 or newPos.x > WIDTH or newPos.y + self.scale < 0 or newPos.y > HEIGHT 
    then self.expire = 0 end

    self.position    = newPos
end


function Bullet:draw()
    self.animator:draw( { x = self.position.x,y = self.position.y } )
end


function Bullet:update()
    if self.expire > os.time() then     --还没有到子弹消失的时间
        self:updatePos()
        self:draw()
    else
        self.expire = 0
    end
end    


--子弹撞击事件的处理函数
--将子弹消亡时间设为0，由子弹管理器移除子弹对象
function Bullet:onCollide( collider )
    self.expire = 0
end