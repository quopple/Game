--[[
    可以发生碰撞的物体的基类
]]

Collider = {}

Collider.scale = 0  --包围盒大小

function Collider:new()
    local obj    = {}
    setmetatable( obj,self )
    self.__index = self

    return obj
end


--碰撞处理函数（接口）
function Collider:onCollide( collider )
end


--碰撞判断函数（接口）
function Collider:collisionDetect( collider )
end