------------------常量----------------------

ZERO_VEC    = { x=0, y=0 }

------------------系统设置常量
GAMENAME    = 'Asteroids'

WIDTH       = 1024
HEIGHT      = 700

BG_IMG      = 'GameRes/stars.jpg'
BGM         = 'GameRes/summer.mp3'
CURSOR      = 'GameRes/nocur.cur'
TEXTBOX_IMG = 'GameRes/textBox.png'
------------------游戏数值常量

--------小行星
ASTEROID_SPEED      = 5
ASTEROID_MIN_NUM    = 5     --最少存在多少小行星
ASTEROID_MAX_NUM    = 15    --最多存在多少小行星
ASTEROID_MAX_VAL    = 24    --小行星在x方向和y方向速度分量的最大值
ASTEROID_MAX_VAL_SQ = ASTEROID_MAX_VAL*ASTEROID_MAX_VAL
ASTEROID_ACCELERATION = 0.15   --小行星加速度值
ASTEROID_TYPE ={
  'GameRes/asteroid1.png',
  'GameRes/asteroid2.png',
  'GameRes/asteroid3.png',
  'GameRes/asteroid4.png',
  'GameRes/asteroid5.png',
  'GameRes/asteroid6.png',
}

--------子弹
BULLET_LIFE     = 5    --子弹生存周期（单位为s）
BULLET_SPEED    = 20   --子弹速度

BULLET_IMG      = 'GameRes/bullet.png'


--------飞船
SHIP_FIRE_FREQUENCY = 0.3       --子弹发射间隔ms
SHIP_ACCELERATION   = 2         --飞船加速度a
SHIP_MAX_VAL        = 24        --飞船在x方向和y方向速度分量的最大值
SHIP_INITX          = WIDTH/2   --飞船初始位置（窗口中心）
SHIP_INITY          = HEIGHT/2

SHIP_IMG            = 'GameRes/ship.png'

------------------全局函数----------------------

--合成RGB
function RGB(r,g,b)       
    local c = r+g*256+b*65536
    return c
end


--[[
    作用：判断两个圆是否相交或包含
    参数：
    x1,y1   : 圆1的圆点坐标
    r1      : 圆1的半径
    x2,y2   : 圆2的圆点坐标
    r2      : 圆2的半径
]]
function isOverlap( x1,y1,r1,x2,y2,r2 )
    local xx = x2 - x1
    local yy = y2 - y1
    local rr = r1 + r2
    if xx*xx + yy*yy < rr*rr then
        return true
    else
        return false
    end
end


--[[
    作用：检测点是否在长方形内
    参数：
    px,py   : 点坐标
    bx,by   : 长方形左上角坐标
    w       ：长方形长度，即x坐标范围
    h       : 长方形宽度，即y坐标范围
]]
function isPointInBox( px,py,bx,by,w,h )
    if ( bx < px ) and ( px < bx + w ) and 
       ( by < py ) and ( py < by + h ) then
        return true
    else
        return false
    end
end


--[[
    作用：检测两个矩形是否相交或包含
    方法：判断一个矩形的四个点与另一个矩形的位置关系
    参数：
    x1,y1 : 矩形1的左上角点坐标
    w1,h1 ：矩形1的长和宽
    x2,y2 : 矩形2的左上角点坐标
    w2,h2 ：矩形2的长和宽
]]
function isBoxOverlap( x1,y1,w1,h1,x2,y2,w2,h2 )
    --检测矩形1是否在矩形2内或与矩形2相交
    local xUpLeft   = x1        --左上角点坐标
    local yUpLeft   = y1
    local xUpRight  = x1 + w1   --右上角点坐标
    local yUpRight  = y1
    local xDownLeft = x1        --左下角点坐标
    local yDownLeft = y1 + h1
    local xDownRight = x1 + w1  --右下角点坐标
    local yDownRight = y1 + h1

    if isPointInBox( xUpLeft,yUpLeft,x2,y2,w2,h2 )
    or isPointInBox( xUpRight,yUpRight,x2,y2,w2,h2 )
    or isPointInBox( xDownLeft,yDownLeft,x2,y2,w2,h2 )
    or isPointInBox( xDownRight,yDownRight,x2,y2,w2,h2 ) then
        return true
    end

    --检测矩形2是否在矩形1内或与矩形1相交
    xUpLeft     = x2        --左上角点坐标
    yUpLeft     = y2
    xUpRight    = x2 + w2   --右上角点坐标
    yUpRight    = y2
    xDownLeft   = x2        --左下角点坐标
    yDownLeft   = y2 + h2
    xDownRight  = x2 + w2   --右下角点坐标
    yDownRight  = y2 + h2

    if isPointInBox( xUpLeft,yUpLeft,x1,y1,w1,h1 )
    or isPointInBox( xUpRight,yUpRight,x1,y1,w1,h1 )
    or isPointInBox( xDownLeft,yDownLeft,x1,y1,w1,h1 )
    or isPointInBox( xDownRight,yDownRight,x1,y1,w1,h1 ) then
        return true
    end

    return false
end