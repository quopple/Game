--[[
    飞船类：玩家操作的对象
]]
require('Vec2')
require('Definition')
require('Collider')

Ship = Collider:new()

Ship.position     = { x = SHIP_INITX, y = SHIP_INITY }  --初始位置，默认为屏幕中央
Ship.velocity     = ZERO_VEC                            --初始速度，默认为0
Ship.orientation  = 270                 --角度  逆时针    
Ship.acceleration = SHIP_ACCELERATION   --每次加速时的加速度值
Ship.alive        = true

Ship.nextShooting = 0                   --下次可以开火的时间

Ship.animator     = nil


--img是飞船八方向图片id的数组 （逆时针）
function Ship:new( animator,scale )
    local obj    = {}
    setmetatable( obj,self )
    self.__index = self

    obj.animator = animator
    obj.scale    = scale
    return obj
end


function Ship:updatePos( )
    local newPos = Vec2.add( self.position,self.velocity)   

    if      newPos.x > WIDTH then newPos.x = -self.scale     --飞船移动到屏幕外面时，wrap
    elseif  newPos.x + self.scale < 0 then newPos.x = WIDTH   end
    if      newPos.y > HEIGHT then newPos.y = -self.scale 
    elseif  newPos.y + self.scale < 0 then  newPos.y = HEIGHT end

    self.position = newPos
end


--使用圆包围盒进行碰撞检测（collisionDetect 是主动碰撞的对象要定义的）
function Ship:collisionDetect( collider )
--[[
    if isBoxOverlap( self.position.x,self.position.y,self.scale,self.scale,
                     collider.position.x,collider.position.y,collider.scale,collider.scale) 
    then return true
    else return false
    end
]]
    local r1 = self.scale/2
    local r2 = collider.scale/2
    if isOverlap( self.position.x + r1,self.position.y + r1,r1,
                  collider.position.x + r2,collider.position.y + r2,r2)
    then return true
    else return false
    end
end


function Ship:accelerate()
    local vel        = self.velocity 
    local radian     =  math.rad( self.orientation )
    local accelerVec = Vec2:new( math.cos( radian ) * self.acceleration ,math.sin( radian ) * self.acceleration )
    vel   = Vec2.add( vel,accelerVec )
    vel.x =( math.abs( vel.x ) <= SHIP_MAX_VAL ) and vel.x or ( vel.x/math.abs(vel.x)*SHIP_MAX_VAL )   --约束xy方向上的速度分量最大值
    vel.y =( math.abs( vel.y ) <= SHIP_MAX_VAL ) and vel.y or ( vel.y/math.abs(vel.y)*SHIP_MAX_VAL )
    self.velocity    = vel
end


function Ship:draw()
    self.animator:draw( { index = self.orientation ,x = self.position.x, y = self.position.y } )
end


function Ship:update()  
    self:updatePos()
    self:draw()
end


--开火时，用子弹工厂来生成子弹对象，更新下次可以开火的时间
function Ship:fire( bulletFactory )
    local cur = os.clock()
    if self.nextShooting <= cur then        --当前时间可以开火  
        local radius = self.scale/2
        bulletFactory:genBullet(self.position.x + radius,self.position.y + radius,self.orientation)
        self.nextShooting = cur +  SHIP_FIRE_FREQUENCY 
    end
end


--飞船受到撞击时，游戏结束
function Ship:onCollide( collider )
    self.alive = false
end