--[[
    子弹管理器：负责产生子弹和对子弹对象的管理
]]
require( "Bullet" )

BulletManager = {}

BulletManager.bulletPool = {}   --子弹对象池
BulletManager.animator   = nil  --子弹图片
BulletManager.scale      = 0    --子弹大小

function BulletManager:new( animator ,scale)
    local obj    = {}
    setmetatable( obj,self )
    self.__index = self

    obj.animator      = animator
    obj.scale    = scale
    return obj
end


--产生子弹对象
function BulletManager:genBullet(x,y,orientation)
    local bullet    = Bullet:new( x,y,orientation,self.animator, self.scale)
    self.bulletPool[ #self.bulletPool + 1 ] = bullet
end


--每一帧更新所有子弹对象，当子弹生命周期<=0，移除子弹
function BulletManager:update()
    for i,v in ipairs( self.bulletPool ) do
        v:update()
        if v.expire <= 0 then table.remove( self.bulletPool,i ) end
    end
end


--清空子弹对象池
function BulletManager:destroy()
    for i,v in ipairs( self.bulletPool ) do
        table.remove( self.bulletPool,i )
    end
end