CollisionTraverser = {}

CollisionTraverser.queue = { } --记录碰撞检测队列  每个元素为{ Collider, toBeCollide }


--添加要处理的碰撞对 
--collider是主动碰撞的对象
--toBeCollide是被碰撞的对象数组
function CollisionTraverser:addColliderGroup( collider,toBeCollide )
    if  not  ( collider.collisionDetect and collider.onCollide ) then      --collider没有定义所需函数，不可以作为主动碰撞器
        return
    end

    for i = 1,#toBeCollide do
        if not toBeCollide[i].onCollide then return end     --当被碰撞对象集合中有未定义碰撞处理器的对象时，不放入碰撞对，保证该调用是原子的
    end
    self.queue[ #self.queue + 1 ] = { collider,toBeCollide }
end


--检测所有碰撞对是否发生了碰撞
function CollisionTraverser:update()
    for i =1,#self.queue do
        local collider      = self.queue[i][1]
        local toBeCollide   = self.queue[i][2]

        for j = 1,#toBeCollide do
            local collider2 = toBeCollide[j]
--log:print( 'coll 27   collider  pos :',collider.position.x,collider.position.y,'   toBeCollide pos:', collider2.position.x,collider2.position.y)
            if collider:collisionDetect( collider2 ) then
                collider:onCollide(collider2)
                collider2:onCollide(collider)
            end
        end
    end
end