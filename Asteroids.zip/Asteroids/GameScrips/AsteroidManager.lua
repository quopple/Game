--[[
    小行星管理器：负责生成和管理小行星对象
]]
require( "Asteroid" )
require( "Definition" )

AsteroidManager = {}

AsteroidManager.asteroidPool = {}   --小行星对象池
AsteroidManager.typeSet      = nil  --数组 记录所有类型的小行星 {animator，scale}

function AsteroidManager:new( typeSet )
    local obj       = {}
    setmetatable( obj,self )
    self.__index    = self

    obj.typeSet     = typeSet
    return obj
end


--当现有小行星数量少于设定最大值时，生成一个小行星对象
function AsteroidManager:genAsteroid( ship )
    if #self.asteroidPool < ASTEROID_MAX_NUM then
        local type  = math.random( #self.typeSet )       --随机选取一个小行星类型
        local x     = nil        
        local y     = nil 
        local orientation = math.random( 360 )      --随机选择小行星移动方向
        local r     = self.typeSet[type].scale/2 
        repeat
            x = math.random( WIDTH )
            y = math.random( HEIGHT )
        until( not isOverlap( x,y,r, ship.position.x, ship.position.y,ship.scale/2) )      --随机生成一个不与飞船重叠的小行星位置

        local asteroid = Asteroid:new( x,y,self.typeSet[type].scale, orientation,self.typeSet[type].animator )
        --将生成的小行星对象放入池中进行管理
        self.asteroidPool[ #self.asteroidPool + 1 ] = asteroid      
        return asteroid
    end
end


function AsteroidManager:update(surviveTime)
    for i,v in ipairs( self.asteroidPool ) do
        v:update(surviveTime)
    end
end


--清空小行星对象池
function AsteroidManager:destroy()
    for i,v in ipairs( self.asteroidPool ) do
        table.remove( self.asteroidPool,i )
    end
end