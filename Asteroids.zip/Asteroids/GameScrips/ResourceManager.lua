module("ResourceManager",package.seeall)

require( "Painter" )

local resPool = {}   --资源池


--根据提供的文件路径及缩放因子来索引图片，不存在时，加载。否则直接从资源池中返回
function getImage( path,scale )
    scale   = scale or 1

    local v = resPool[path]
    if v then 
        local imgID = v[scale]
        if imgID  then 
        return imgID end
    end

    resPool[path]   = v or {}

    if      string.match( string.lower( path ),'%.jpg$'  )  then
        resPool[path][scale] = Painter.addJPG( path )
    elseif  string.match( string.lower( path ),'%.png$'  )  then
        resPool[path][scale] = Painter.addImage( path )
    else
        log:print('can\'t load image file : %s',path)
        return -1
    end

    return resPool[path][scale]
end


function getMusic( path )
    local   id              = resPool[path]
    if      id  then return id
    else    resPool[path]   = Painter.addMusic(path)
    end
    return  resPool[path]
end